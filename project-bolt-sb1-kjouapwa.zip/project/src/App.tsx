import React, { useState } from 'react';
import { ChefHat, LogOut } from 'lucide-react';
import { RecipeCard } from './components/RecipeCard';
import { SearchBar } from './components/SearchBar';
import { AuthModal } from './components/AuthModal';
import { ShareRecipeModal } from './components/ShareRecipeModal';
import { AuthProvider, useAuth } from './hooks/useAuth';
import type { Recipe, SearchFilters } from './types';

// Sample data - In a real app, this would come from an API
const SAMPLE_RECIPES: Recipe[] = [
  {
    id: '1',
    title: 'Classic Margherita Pizza',
    description: 'A traditional Italian pizza with fresh basil, mozzarella, and tomato sauce on a perfectly crispy crust.',
    imageUrl: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca',
    cookingTime: 45,
    difficulty: 'Medium',
    ingredients: ['Pizza dough', 'Tomatoes', 'Mozzarella', 'Basil', 'Olive oil'],
    instructions: ['Prepare the dough', 'Add toppings', 'Bake at 450°F'],
    userId: '1',
    likes: 245,
    createdAt: '2024-03-15T10:00:00Z',
  },
  {
    id: '2',
    title: 'Chocolate Lava Cake',
    description: 'Decadent chocolate cake with a gooey molten center, served warm with vanilla ice cream.',
    imageUrl: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb',
    cookingTime: 25,
    difficulty: 'Easy',
    ingredients: ['Dark chocolate', 'Butter', 'Eggs', 'Sugar', 'Flour'],
    instructions: ['Melt chocolate', 'Mix ingredients', 'Bake until edges are set'],
    userId: '2',
    likes: 189,
    createdAt: '2024-03-14T15:30:00Z',
  },
];

function AppContent() {
  const { user, isAuthenticated, login, register, logout } = useAuth();
  const [recipes, setRecipes] = useState(SAMPLE_RECIPES);
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    difficulty: '',
    cookingTime: undefined,
  });
  const [showFavorites, setShowFavorites] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [authModal, setAuthModal] = useState<{ isOpen: boolean; mode: 'login' | 'register' }>({
    isOpen: false,
    mode: 'login',
  });
  const [shareModal, setShareModal] = useState(false);

  const filteredRecipes = recipes.filter(recipe => {
    if (showFavorites && !favorites.includes(recipe.id)) {
      return false;
    }
    if (filters.query && !recipe.title.toLowerCase().includes(filters.query.toLowerCase())) {
      return false;
    }
    if (filters.difficulty && recipe.difficulty !== filters.difficulty) {
      return false;
    }
    if (filters.cookingTime && recipe.cookingTime > filters.cookingTime) {
      return false;
    }
    return true;
  });

  const handleFavoriteToggle = (recipeId: string) => {
    setFavorites(prev => 
      prev.includes(recipeId) 
        ? prev.filter(id => id !== recipeId)
        : [...prev, recipeId]
    );
  };

  const handleDelete = (recipeId: string) => {
    setRecipes(prev => prev.filter(recipe => recipe.id !== recipeId));
  };

  const handleShareRecipe = (recipeData: Omit<Recipe, 'id' | 'userId' | 'likes' | 'createdAt'>) => {
    const newRecipe: Recipe = {
      ...recipeData,
      id: Math.random().toString(36).substr(2, 9),
      userId: user?.id || '',
      likes: 0,
      createdAt: new Date().toISOString(),
    };
    setRecipes(prev => [newRecipe, ...prev]);
    setShareModal(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div 
        className="h-[400px] bg-cover bg-center relative"
        style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1543353071-873f17a7a088)' }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <header className="relative">
          <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ChefHat className="w-8 h-8 text-white" />
                <h1 className="text-2xl font-bold text-white">RecipeShare</h1>
              </div>
              <div className="flex items-center gap-4">
                {isAuthenticated ? (
                  <>
                    <button 
                      onClick={() => setShowFavorites(!showFavorites)}
                      className={`px-4 py-2 rounded-lg transition-colors ${
                        showFavorites 
                          ? 'bg-white text-blue-600' 
                          : 'bg-blue-600 text-white hover:bg-blue-700'
                      }`}
                    >
                      {showFavorites ? 'All Recipes' : 'My Favorites'}
                    </button>
                    <button 
                      onClick={() => setShareModal(true)}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Share Recipe
                    </button>
                    <button 
                      onClick={logout}
                      className="text-white hover:text-gray-200"
                    >
                      <LogOut className="w-6 h-6" />
                    </button>
                  </>
                ) : (
                  <div className="space-x-4">
                    <button 
                      onClick={() => setAuthModal({ isOpen: true, mode: 'login' })}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Sign In
                    </button>
                    <button 
                      onClick={() => setAuthModal({ isOpen: true, mode: 'register' })}
                      className="px-4 py-2 bg-white text-blue-600 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      Sign Up
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Discover & Share Amazing Recipes
          </h2>
          <p className="text-xl text-gray-200 max-w-2xl">
            Join our community of food lovers and share your favorite recipes with the world
          </p>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <SearchBar filters={filters} onFilterChange={setFilters} />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRecipes.map(recipe => (
            <RecipeCard 
              key={recipe.id} 
              recipe={recipe}
              isFavorite={favorites.includes(recipe.id)}
              onFavoriteToggle={handleFavoriteToggle}
              onDelete={handleDelete}
            />
          ))}
        </div>

        {filteredRecipes.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No recipes found matching your criteria.</p>
          </div>
        )}
      </main>

      <AuthModal 
        isOpen={authModal.isOpen}
        mode={authModal.mode}
        onClose={() => setAuthModal({ ...authModal, isOpen: false })}
        onSubmit={(email, password) => {
          if (authModal.mode === 'login') {
            login(email, password);
          } else {
            register(email, password);
          }
          setAuthModal({ ...authModal, isOpen: false });
        }}
      />

      <ShareRecipeModal
        isOpen={shareModal}
        onClose={() => setShareModal(false)}
        onSubmit={handleShareRecipe}
      />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;