import React from 'react';
import { Clock, Heart, Trash2 } from 'lucide-react';
import type { Recipe } from '../types';
import { useAuth } from '../hooks/useAuth';

interface RecipeCardProps {
  recipe: Recipe;
  isFavorite?: boolean;
  onFavoriteToggle: (recipeId: string) => void;
  onDelete: (recipeId: string) => void;
}

export function RecipeCard({ recipe, isFavorite, onFavoriteToggle, onDelete }: RecipeCardProps) {
  const { user } = useAuth();
  const isOwner = user?.id === recipe.userId;

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow group">
      <div className="relative">
        <img 
          src={recipe.imageUrl} 
          alt={recipe.title}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {user && (
          <button 
            onClick={() => onFavoriteToggle(recipe.id)}
            className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-md hover:scale-110 transition-transform"
          >
            <Heart 
              className={`w-5 h-5 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
            />
          </button>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xl font-semibold text-gray-800 truncate">
            {recipe.title}
          </h3>
          <span className={`px-2 py-1 rounded-full text-sm font-medium ${
            recipe.difficulty === 'Easy' ? 'bg-green-100 text-green-800' :
            recipe.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }`}>
            {recipe.difficulty}
          </span>
        </div>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {recipe.description}
        </p>

        <div className="flex items-center justify-between text-gray-500 text-sm">
          <span className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {recipe.cookingTime} min
          </span>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1">
              <Heart className="w-4 h-4" />
              {recipe.likes}
            </span>
            {isOwner && (
              <button 
                onClick={() => onDelete(recipe.id)}
                className="text-red-500 hover:text-red-700"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}