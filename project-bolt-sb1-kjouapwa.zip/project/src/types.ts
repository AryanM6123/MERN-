export interface Recipe {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  cookingTime: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  ingredients: string[];
  instructions: string[];
  userId: string;
  likes: number;
  createdAt: string;
}

export interface User {
  id: string;
  email: string;
  favorites: string[];
}

export interface SearchFilters {
  difficulty?: string;
  cookingTime?: number;
  query: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}